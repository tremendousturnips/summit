module.exports.Auth = require('./auths');
module.exports.Profile = require('./profiles');