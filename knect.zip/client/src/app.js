import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(<h1>Hello World from React</h1>, document.getElementById('root'));
