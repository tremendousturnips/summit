const config = require('config');

module.exports = config['knex'];
